#include "task.h"

#define DISTANCE_MAX 400
#define SOUND_VELOCITY 0.034
ADXL345_Data_t GY291_Data;

// ��̨����-���ٶȲ���
void task_MeasureACC(void)
{
	ADXL345_Read(&GY291_Data);
	
	printf("X-axis acc is: %f \r\n",GY291_Data.ax);
	printf("Y-axis acc is: %f \r\n",GY291_Data.ay);
	printf("Z-axis acc is: %f \r\n\r\n",GY291_Data.az);
}
void task_MeasureSonar(void)
{
	float distance;
	distance = GET_EchoTime() * SOUND_VELOCITY /2.0;
	if(distance<DISTANCE_MAX)
	{
		printf("distance is %f cm\r\n",distance);
	}
	else 
	{}		 
}
