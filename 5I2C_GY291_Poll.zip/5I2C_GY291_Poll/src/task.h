#ifndef __WSF_TASK_H
#define __WSF_TASK_H

#include <stdbool.h>
#include <math.h>    	//Keil library  
#include "stdio.h"
#include "stm32f10x.h"
#include "drv_i2c_adxl345.h"

typedef struct{
	uint32_t CapState;
	uint32_t RisingCapVal;
	uint32_t FallingCapVal;
}SONAR;

// �������
void task_MeasureACC(void);
void task_MeasureSonar(void);
void task_MeasureSonar(void);
uint32_t	GET_EchoTime(void);

extern unsigned int flag_MeasureACC;			// ��ȡ���ٶȱ�־
extern unsigned int flag_Sonar1Measure;

// Ӳ�����
void TIM4_Config(void);	// TIM
void TIM3_Config(void);
void TIM2_Config(void);
void USART_Config(void);						// USART

#endif 
