#ifndef __Dev_ADXL345_H
#define __Dev_ADXL345_H

typedef struct ADXL345_Data_t
{
	float ax;			// x���ٶ�
	float ay;			// y���ٶ�
	float az;			// z���ٶ�
}ADXL345_Data_t;

void ADXL345_Init(void);
void ADXL345_Read(ADXL345_Data_t *pGY291);

#endif
