#ifndef __DRV_I2C_H
#define __DRV_I2C_H
#include "stm32f10x.h"

void I2C_Config(void);

void I2C_Write(u8 SlaveAddress,u8 RegAddress,u8 DataLen,u8 *pDataBuf);
void I2C_Single_Write(u8 SlaveAddress,u8 RegAddress,u8 byteData);

void I2C_Read(u8 SlaveAddress,u8 RegAddress,u8 DataLen,u8 *pDataBuf);
u8 I2C_Single_Read(u8 SlaveAddress,u8 RegAddress);

#endif
