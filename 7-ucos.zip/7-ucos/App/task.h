#ifndef __WSF_TASK_H
#define __WSF_TASK_H

#include <stdbool.h>
#include <math.h>    	//Keil library  
#include "stm32f10x.h"
#include "stdio.h"
#include "ucos_ii.h"
#include "drv_i2c_gy9250.h"

// �������
void Task_Init(void);							// �����ʼ��
void task_MeasureIMU(void *pdata);
void task_MeasureSNOR(void *pdata);

extern OS_FLAG_GRP *IMUFlagStatus;				// �¼���־
extern OS_FLAG_GRP *SNORFlagStatus;

// Ӳ�����
void TIM_Config(void);							// TIM
void USART_Config(void);						// USART

#endif 
