/*--------------File Info------------------------------------------------------
** File name:               os_cpu_c.c
** Latest modified Date:    2014-07-27
** Latest Version:          1.0
** Descriptions:            ��COS-II��Cortex-M3�ϵ���ֲ����C���Բ��֣���realview����
**
**-----------------------------------------------------------------------------
** Version:                 1.0
** Descriptions:            The original version
**
**-----------------------------------------------------------------------------
** Modified by:             
** Modified date:           
** Version:                 
** Descriptions:            
**
*******************************************************************************/
#define  OS_CPU_GLOBALS
#include "stm32f10x.h"

#include "ucos_ii.h"

/*******************************************************************************
** Function name:           OSStartHighRdy
** Descriptions:            uC/OS-II����ʹ��OSStartHighRdy���е�һ������
** input parameters:        none
** output parameters:       none
** Returned value:          none
**-------------------------------------------------------------------------
*******************************************************************************/
__asm void OSStartHighRdy (void)
{
    IMPORT  OSRunning
    IMPORT  OSTCBCur
    IMPORT  OSTCBHighRdy
    IMPORT  OSTaskSwHook

    preserve8

	BL 		OSTaskSwHook 		// �����û���Hook�������պ��� 
		
	LDR		R4, =OSRunning 		// ��OSRunning��1������������OS��ʼ���� 
	MOVS	R5, #1 
	STRB	R5, [R4] 
		
	LDR		R4, =OSTCBHighRdy 	// αָ�ȡ�ô洢OSTCBHighRdy�ĵ�ַ 
	LDR		R4, [R4] 			// �õ�������ȼ�����������ջ��ַ 

	LDR		R6, [R4] 			// �л���������Ķ�ջSP = OSTCBHighRdy->OSTCBStkPtr
    MSR     MSP, R6
	     
    POP     {R4-R7}				// �ָ�R4~R7
	
	POP     {R0-R3}				// �ָ�R8~R11
	MOV     R8,R0
	MOV     R9,R1
	MOV     R10,R2
	MOV     R11,R3
	
	ADD     SP,SP,#0x10			// ����ջָ�룬�ָ�PSR PC LR R12
	POP     {R0-R3}
	MOV     R12,R0
	MOV     LR,R1
	PUSH    {R2}				// PC��ջ
	MSR     PSR, R3
	
	SUB     SP,SP,#0x1C			// ����ջָ�룬�ָ�R0~R3
	POP     {R0-R3}
	
	ADD     SP,SP,#0x0C			// ����ջָ��
    POP     {PC}				// PC��ջ
	ALIGN
}

/*******************************************************************************
** Function name:           OSIntCtxSw
** Descriptions:            �жϼ�����Ⱥ���
** input parameters:        none
** output parameters:       none
** Returned value:          none
**-------------------------------------------------------------------------
*******************************************************************************/
void OSIntCtxSw (void)
{
    //NVIC_SetPendingIRQ(PendSV_IRQn);	// ����ʹ�ã�Ҫ��IRQn�Ǹ�
    SCB->ICSR = SCB_ICSR_PENDSVSET_Msk;	// ����PendSV�жϣ����������л�
}

/*******************************************************************************
** Function name:           PendSV_Handler
** Descriptions:            uC/OS-II������Ⱥ���
** input parameters:        none
** output parameters:       none
** Returned value:          none
*******************************************************************************/
__asm void PendSV_Handler(void) 
{
    IMPORT  OSTCBCur
    IMPORT  OSTCBHighRdy
    IMPORT  OSPrioCur
    IMPORT  OSPrioHighRdy
    IMPORT  OSTaskSwHook

    preserve8

	// �����쳣���������Զ����α���{R0-R3,R12,LR,PC,xPSR}��LR = 0xFFFFFFF9
    CPSID   I					// ���ж�
	MOV		R12, LR  			// �ؼ�������LR��R12���Ա��쳣����

	MOV     R0,R8
	MOV     R1,R9
	MOV     R2,R10
	MOV     R3,R11
	PUSH    {R0-R3}				// ����R8-R11
	
	PUSH    {R4-R7}				// ����R4-R7
	
	LDR		R4, =OSTCBCur 		// �õ���ǰTCB��ĵ�ַ������R4 
	LDR		R5, [R4] 			// ��OSTCBCur�е�ֵ����R5��ע��OSTCBCur�����ָ�� 
    MRS     R6, MSP
	STR		R6, [R5] 			// ����ǰ�����SP����OSTCBCur���ָ����ȥ 

	BL		OSTaskSwHook 		// ����Hook��������Ϊ�պ��� 
    
    LDR     R4, =OSPrioCur
    LDR     R5, =OSPrioHighRdy
    LDRB    R6, [R5]
    STRB    R6, [R4]			// OSPrioCur = OSPrioHighRdy

    LDR     R4, =OSTCBCur
    LDR     R5, =OSTCBHighRdy
    LDR     R6, [R5]
    STR     R6, [R4]			// OSTCBCur = OSTCBHighRdy

	LDR		R6, [R6]			// ��R6��ȡ��Ҫ�ָ��������ջ��ָ��SP = OSTCBHighRdy->OSTCBStkPtr
    MSR     MSP, R6

    POP     {R4-R7}				// �ָ�R4~R7
	
	POP     {R0-R3}				// �ָ�R8~R11
	MOV     R8,R0
	MOV     R9,R1
	MOV     R10,R2
	MOV     R11,R3

	CPSIE   I     				// ���ж�
	BX		R12					// �쳣���أ��������Զ����λָ�{R0-R3,R12,LR,PC,xPSR}
	ALIGN
}


/*******************************************************************************
** Function name:       SysTick_Handler
** Descriptions:        ϵͳ�����ж�
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*******************************************************************************/
void SysTick_Handler (void)
{
    OSIntEnter();
    OSTimeTick();				// ϵͳ���Ĵ���
    OSIntExit();				// ���������л�
}
 
//****************************************************************************
//                                   CRITICAL SECTION METHOD 3 FUNCTIONS
//
// Description: Disable/Enable interrupts by preserving the state of interrupts.
//              Generally speaking you would store the state of the interrupt 
//              disable flag in the local variable 'cpu_sr' and then disable 
//              interrupts.  'cpu_sr' is allocated in all of uC/OS-II's functions 
//			    that need to disable interrupts.  You would restore the interrupt 
//              disable state by copying back 'cpu_sr' into the CPU's status register.
//
// Prototypes :     OS_CPU_SR  OS_CPU_SR_Save(void);
//                  void       OS_CPU_SR_Restore(OS_CPU_SR cpu_sr);
//
//
// Note(s)    : 1) These functions are used in general like this:
//
//          void Task (void *p_arg)
//          {
//          #if OS_CRITICAL_METHOD == 3 /* Allocate storage for CPU status register */
//                OS_CPU_SR  cpu_sr;
//          #endif
//
//                     :
//                     :
//                OS_ENTER_CRITICAL();     /* cpu_sr = OS_CPU_SaveSR();  */
//                     :
//                     :
//                OS_EXIT_CRITICAL();      /* OS_CPU_RestoreSR(cpu_sr);  */
//                     :
//                     :
//           }
//*****************************************************************************
__asm OS_CPU_SR OS_CPU_SR_Save(void)
{
    preserve8

    MRS     R0, PRIMASK  	//; Set prio int mask to mask all (except faults)
    CPSID   I				// ���ж�
    BX      LR
}

__asm void OS_CPU_SR_Restore(OS_CPU_SR cpu_sr)
{
    preserve8

    MSR     PRIMASK, R0		// �ָ�ԭ���ж��������
    BX      LR
}


/*******************************************************************************
** Function name:           OSTaskStkInit
** Descriptions:            ���ݼ�ջ������ջ��ʼ�����룬����������ʧ�ܻ�ʹϵͳ����
** input parameters:        task:  ����ʼִ�еĵ�ַ
**                          p_arg: ���ݸ�����Ĳ���
**                          ptos:  �����ջ��ʼλ��
**                          opt:   ���Ӳ���,��ǰ�汾���ڱ���������,
** output parameters:       none
** Returned value:          ��ջλ��
**-------------------------------------------------------------------------
*******************************************************************************/
OS_STK *OSTaskStkInit (void (*task)(void *pd), void *p_arg, OS_STK *ptos, INT16U opt)
{
    OS_STK *pstk;    

    opt     = opt;							// �������������
    pstk    = ptos;							// ��ȡ��ջָ��
	    
	// �����������ʹ��&TaskStk[TASK_STK_SIZE - 1]�����һ��stk�����Լ�
    //*(stk) = (OS_STK)task;                  // xPSR
	// �����������ʹ��&TaskStk[TASK_STK_SIZE]�����һ��stkҪ�Լ�����׼���ݼ�ջ��
    *--pstk = (INT32U)0x01000000;			//  xPSR
    *--pstk = (INT32U)task;					//  PC���������
    *--pstk = (INT32U)0;					//  LR
    *--pstk = (INT32U)0;					//  R12
    *--pstk = (INT32U)0;					//  R3
    *--pstk = (INT32U)0;					//  R2
    *--pstk = (INT32U)0;					//  R1
    *--pstk = (INT32U)p_arg;				//  R0 �������
    *--pstk = (INT32U)0;					//  R11
    *--pstk = (INT32U)0;					//  R10
    *--pstk = (INT32U)0;					//  R9
    *--pstk = (INT32U)0;					//  R8
    *--pstk = (INT32U)0;					//  R7
    *--pstk = (INT32U)0;					//  R6
    *--pstk = (INT32U)0;					//  R5
    *--pstk = (INT32U)0;					//  R4

    return (pstk);
}


/*******************************************************************************
  uCOSII OS���Ӻ���
*******************************************************************************/

#if OS_CPU_HOOKS_EN
/*******************************************************************************
*                                       OS INITIALIZATION HOOK
*                                            (BEGINNING)
*
* Description: This function is called by OSInit() at the beginning of OSInit().
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts should be disabled during this call.
*******************************************************************************/
#if OS_VERSION > 203
void OSInitHookBegin (void)
{
}
#endif                                  /*  OS_VERSION                  */

/*******************************************************************************
*                                       OS INITIALIZATION HOOK
*                                               (END)
*
* Description: This function is called by OSInit() at the end of OSInit().
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts should be disabled during this call.
*******************************************************************************/
#if OS_VERSION > 203
void OSInitHookEnd (void)
{
}
#endif                                   /*  OS_VERSION                  */


/*******************************************************************************
*                                          TASK CREATION HOOK
*
* Description: This function is called when a task is created.
*
* Arguments  : ptcb   is a pointer to the task control block of the task being created.
*
* Note(s)    : 1) Interrupts are disabled during this call.
*******************************************************************************/
void OSTaskCreateHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                         /*  Prevent compiler warning    */
}


/*******************************************************************************
*                                           TASK DELETION HOOK
*
* Description: This function is called when a task is deleted.
*
* Arguments  : ptcb   is a pointer to the task control block of the task being deleted.
*
* Note(s)    : 1) Interrupts are disabled during this call.
*******************************************************************************/
void OSTaskDelHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                          /*  Prevent compiler warning    */
}

/*******************************************************************************
*                                           TASK SWITCH HOOK
*
* Description: This function is called when a task switch is performed.  This 
*			   allows you to perform other operations during a context switch.
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts are disabled during this call.
*              2) It is assumed that the global pointer 'OSTCBHighRdy' points 
*				  to the TCB of the task that
*                 will be 'switched in' (i.e. the highest priority task) and, 
*				  'OSTCBCur' points to the 
*                 task being switched out (i.e. the preempted task).
*******************************************************************************/
void OSTaskSwHook (void)
{
}

/*******************************************************************************
*                                           STATISTIC TASK HOOK
*
* Description: This function is called every second by uC/OS-II's statistics task.
*			   This allows your application to add functionality to the statistics task.
*
* Arguments  : none
*******************************************************************************/
void OSTaskStatHook (void)
{
}

/*******************************************************************************
*                                           OSTCBInit() HOOK
*
* Description: This function is called by OSTCBInit() after setting up most of the TCB.
*
* Arguments  : ptcb    is a pointer to the TCB of the task being created.
*
* Note(s)    : 1) Interrupts may or may not be ENABLED during this call.
*******************************************************************************/
#if OS_VERSION > 203
void OSTCBInitHook (OS_TCB *ptcb)
{
    ptcb = ptcb;                   /*  Prevent Compiler warning    */
}
#endif                             /*  OS_VERSION                  */

/*******************************************************************************
*                                               TICK HOOK
*
* Description: This function is called every tick.
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts may or may not be ENABLED during this call.
*******************************************************************************/
void OSTimeTickHook (void)
{
}


/*******************************************************************************
*                                             IDLE TASK HOOK
*
* Description: This function is called by the idle task.  This hook has been
*			   added to allow you to do  
*              such things as STOP the CPU to conserve power.
*
* Arguments  : none
*
* Note(s)    : 1) Interrupts are enabled during this call.
*******************************************************************************/
#if OS_VERSION >= 251
void OSTaskIdleHook (void)
{
}
#endif                                  /*  OS_VERSION                  */
#endif                                  /*  OS_CPU_GLOBALS              */

/*******************************************************************************
  END FILE
*******************************************************************************/

/*******************************************************************************
  END FILE
*******************************************************************************/
